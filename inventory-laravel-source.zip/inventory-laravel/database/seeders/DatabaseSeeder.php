<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use App\Models\StockMovement;
use App\Models\Supplier;
use App\Models\User;
use App\Services\StockService;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(StockService $stock): void
    {
        // Akun demo (ganti passwordnya sebelum dipakai sungguhan).
        $admin = User::factory()->create([
            'name' => 'Administrator', 'username' => 'admin',
            'email' => 'admin@inventory.test', 'password' => 'admin123', 'role' => 'admin',
        ]);
        $staff = User::factory()->create([
            'name' => 'Staff Gudang', 'username' => 'staff',
            'email' => 'staff@inventory.test', 'password' => 'staff123', 'role' => 'staff',
        ]);

        // 5 kategori, 4 supplier, 50 produk (factory).
        $categories = Category::factory()->count(5)->sequence(
            ['name' => 'Elektronik'], ['name' => 'Alat Tulis'], ['name' => 'Perabot'],
            ['name' => 'Makanan & Minuman'], ['name' => 'Kebersihan'],
        )->create();
        $suppliers = Supplier::factory()->count(4)->create();

        $products = Product::factory()->count(50)->recycle($categories)->create();

        foreach ($products as $product) {
            // Many-to-many: 1-2 supplier acak per produk.
            $product->suppliers()->attach($suppliers->random(rand(1, 2))->pluck('id'));

            // Stok awal lewat service agar tercatat di histori.
            $stock->record($product, StockMovement::TYPE_IN, rand(10, 120), 'Stok awal', $admin);
        }

        // Beberapa barang keluar sebagai data uji.
        foreach ($products->random(12) as $product) {
            $product->refresh();
            $stock->record($product, StockMovement::TYPE_OUT, rand(1, max(1, intdiv($product->stock, 2))), 'Penjualan', $staff);
        }
    }
}
