<?php

return [
    'required' => ':attribute wajib diisi.',
    'string' => ':attribute harus berupa teks.',
    'numeric' => ':attribute harus berupa angka.',
    'integer' => ':attribute harus berupa bilangan bulat.',
    'email' => ':attribute tidak valid.',
    'array' => ':attribute tidak valid.',
    'unique' => ':attribute sudah digunakan.',
    'exists' => ':attribute yang dipilih tidak valid.',
    'in' => ':attribute yang dipilih tidak valid.',
    'max' => [
        'string' => ':attribute maksimal :max karakter.',
        'numeric' => ':attribute tidak boleh lebih dari :max.',
    ],
    'min' => [
        'string' => ':attribute minimal :min karakter.',
        'numeric' => ':attribute tidak boleh kurang dari :min (tidak boleh negatif).',
    ],
    'attributes' => [
        'sku' => 'SKU',
        'name' => 'Nama',
        'category_id' => 'Kategori',
        'price' => 'Harga',
        'minimum_stock' => 'Stok minimum',
        'quantity' => 'Quantity',
        'product_id' => 'Produk',
        'type' => 'Jenis transaksi',
        'username' => 'Username',
        'password' => 'Password',
        'email' => 'Email',
        'role' => 'Role',
        'phone' => 'Telepon',
        'address' => 'Alamat',
        'note' => 'Catatan',
    ],
];
