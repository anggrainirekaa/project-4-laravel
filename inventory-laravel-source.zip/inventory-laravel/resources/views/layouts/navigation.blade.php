<header class="topbar">
    <div class="brand">&#128230; Inventory IMS</div>
    <nav>
        <a href="{{ route('dashboard') }}" @class(['active' => request()->routeIs('dashboard')])>Dashboard</a>
        <a href="{{ route('products.index') }}" @class(['active' => request()->routeIs('products.*')])>Produk</a>
        <a href="{{ route('categories.index') }}" @class(['active' => request()->routeIs('categories.*')])>Kategori</a>
        <a href="{{ route('suppliers.index') }}" @class(['active' => request()->routeIs('suppliers.*')])>Supplier</a>
        <a href="{{ route('stock.index') }}" @class(['active' => request()->routeIs('stock.*')])>Stok</a>
        @if (auth()->user()->isAdmin())
            <a href="{{ route('users.index') }}" @class(['active' => request()->routeIs('users.*')])>User</a>
        @endif
    </nav>
    <div class="userbox">
        <span>{{ auth()->user()->name }} <em class="badge {{ auth()->user()->role }}">{{ auth()->user()->role }}</em></span>
        <form method="POST" action="{{ route('logout') }}" class="inline">
            @csrf
            <button class="btn small ghost">Logout</button>
        </form>
    </div>
</header>
