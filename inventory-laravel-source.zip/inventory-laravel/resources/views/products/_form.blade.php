@php($selectedSuppliers = old('suppliers', $product->exists ? $product->suppliers->pluck('id')->all() : []))

<form method="POST" action="{{ $action }}" class="form">
    @csrf
    @if ($method !== 'POST')
        @method($method)
    @endif

    <div class="row">
        <div>
            <label for="sku">SKU</label>
            <input id="sku" name="sku" value="{{ old('sku', $product->sku) }}">
            <x-field-error name="sku" />
        </div>
        <div>
            <label for="name">Nama Produk</label>
            <input id="name" name="name" value="{{ old('name', $product->name) }}">
            <x-field-error name="name" />
        </div>
    </div>

    <div class="row">
        <div>
            <label for="category_id">Kategori</label>
            <select id="category_id" name="category_id">
                <option value="">-- pilih --</option>
                @foreach ($categories as $category)
                    <option value="{{ $category->id }}" @selected(old('category_id', $product->category_id) == $category->id)>{{ $category->name }}</option>
                @endforeach
            </select>
            <x-field-error name="category_id" />
        </div>
        <div>
            <label for="price">Harga (Rp)</label>
            <input id="price" name="price" value="{{ old('price', $product->exists ? (float) $product->price : '') }}">
            <x-field-error name="price" />
        </div>
    </div>

    <label for="minimum_stock">Stok Minimum</label>
    <input id="minimum_stock" name="minimum_stock" value="{{ old('minimum_stock', $product->minimum_stock) }}">
    <x-field-error name="minimum_stock" />

    <label>Supplier (many-to-many)</label>
    <div class="checks">
        @foreach ($suppliers as $supplier)
            <label>
                <input type="checkbox" name="suppliers[]" value="{{ $supplier->id }}" @checked(in_array($supplier->id, $selectedSuppliers))>
                {{ $supplier->name }}
            </label>
        @endforeach
    </div>

    <p style="margin-top:18px">
        <button type="submit" class="btn">Simpan</button>
        <a class="btn gray" href="{{ route('products.index') }}">Batal</a>
    </p>
</form>
