@extends('layouts.app')

@section('title', $product->name)

@section('content')
    <div class="page-head">
        <div>
            <h1>{{ $product->name }}</h1>
            <p class="sub">{{ $product->sku }} &middot; Kategori {{ $product->category->name }}</p>
        </div>
        <div>
            <a class="btn green" href="{{ route('stock.create', ['type' => 'in', 'product_id' => $product->id]) }}">+ Barang Masuk</a>
            <a class="btn danger" href="{{ route('stock.create', ['type' => 'out', 'product_id' => $product->id]) }}">- Barang Keluar</a>
            <a class="btn" href="{{ route('products.edit', $product) }}">Edit</a>
        </div>
    </div>

    <div class="grid g2">
        <div class="card">
            <h2>Detail Produk</h2>
            <dl class="detail">
                <dt>Harga</dt><dd>{{ $product->price_rupiah }}</dd>
                <dt>Stok saat ini</dt>
                <dd><span class="badge {{ $product->isLowStock() ? 'low' : 'okb' }}">{{ $product->stock }}</span> (minimum {{ $product->minimum_stock }})</dd>
                <dt>Supplier</dt>
                <dd>{{ $product->suppliers->pluck('name')->join(', ') ?: '-' }}</dd>
            </dl>
        </div>
        <div class="card">
            <h2>10 Transaksi Terakhir</h2>
            <table>
                <tr><th>Waktu</th><th>Jenis</th><th class="right">Qty</th><th>Oleh</th></tr>
                @forelse ($movements as $m)
                    <tr>
                        <td>{{ $m->created_at->format('d-m-Y H:i') }}</td>
                        <td><span class="badge {{ $m->type }}">{{ $m->type === 'in' ? 'Masuk' : 'Keluar' }}</span></td>
                        <td class="right">{{ $m->quantity }}</td>
                        <td>{{ $m->user->name }}</td>
                    </tr>
                @empty
                    <tr><td colspan="4" class="muted">Belum ada transaksi.</td></tr>
                @endforelse
            </table>
        </div>
    </div>
    <a class="btn gray" href="{{ route('products.index') }}">&laquo; Kembali ke daftar</a>
@endsection
