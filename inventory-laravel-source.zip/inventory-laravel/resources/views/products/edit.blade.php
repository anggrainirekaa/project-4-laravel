@extends('layouts.app')

@section('title', 'Edit Produk')

@section('content')
    <h1>Edit Produk</h1>
    <p class="sub">Mengubah data produk {{ $product->sku }}. Stok diubah lewat transaksi barang masuk/keluar.</p>
    <div class="card">
        @include('products._form', ['action' => route('products.update', $product), 'method' => 'PUT'])
    </div>
@endsection
