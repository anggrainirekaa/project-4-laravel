@extends('layouts.app')

@section('title', 'Produk')

@section('content')
    <h1>Daftar Produk</h1>
    <p class="sub">Search, filter kategori, sorting, dan pagination. Total: {{ $products->total() }} produk.</p>

    <form method="GET" action="{{ route('products.index') }}" class="toolbar">
        <input name="search" placeholder="Cari nama / SKU..." value="{{ request('search') }}">
        <select name="category_id">
            <option value="">Semua kategori</option>
            @foreach ($categories as $category)
                <option value="{{ $category->id }}" @selected(request('category_id') == $category->id)>{{ $category->name }}</option>
            @endforeach
        </select>
        <input type="hidden" name="sort" value="{{ $sort }}">
        <input type="hidden" name="dir" value="{{ $dir }}">
        <button class="btn">Terapkan</button>
        <a class="btn gray" href="{{ route('products.index') }}">Reset</a>
        <span style="flex:1"></span>
        <a class="btn green" href="{{ route('products.create') }}">+ Tambah Produk</a>
    </form>

    <table>
        <tr class="sort">
            <th><x-sort-link column="sku" label="SKU" :sort="$sort" :dir="$dir" /></th>
            <th><x-sort-link column="name" label="Nama" :sort="$sort" :dir="$dir" /></th>
            <th><x-sort-link column="category" label="Kategori" :sort="$sort" :dir="$dir" /></th>
            <th class="right"><x-sort-link column="price" label="Harga" :sort="$sort" :dir="$dir" /></th>
            <th class="right"><x-sort-link column="stock" label="Stok" :sort="$sort" :dir="$dir" /></th>
            <th>Supplier</th>
            <th>Aksi</th>
        </tr>
        @forelse ($products as $product)
            <tr>
                <td class="nowrap">{{ $product->sku }}</td>
                <td><a href="{{ route('products.show', $product) }}">{{ $product->name }}</a></td>
                <td>{{ $product->category->name }}</td>
                <td class="right nowrap">{{ $product->price_rupiah }}</td>
                <td class="right"><span class="badge {{ $product->isLowStock() ? 'low' : 'okb' }}">{{ $product->stock }}</span></td>
                <td class="muted">{{ $product->suppliers->pluck('name')->join(', ') ?: '-' }}</td>
                <td class="nowrap">
                    <a class="btn small" href="{{ route('products.edit', $product) }}">Edit</a>
                    <form method="POST" action="{{ route('products.destroy', $product) }}" class="inline"
                          onsubmit="return confirm('Hapus produk ini?')">
                        @csrf
                        @method('DELETE')
                        <button class="btn small danger">Hapus</button>
                    </form>
                </td>
            </tr>
        @empty
            <tr><td colspan="7" class="muted">Belum ada produk.</td></tr>
        @endforelse
    </table>

    {{ $products->links() }}
@endsection
