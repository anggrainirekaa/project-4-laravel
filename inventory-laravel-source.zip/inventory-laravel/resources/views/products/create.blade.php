@extends('layouts.app')

@section('title', 'Tambah Produk')

@section('content')
    <h1>Tambah Produk</h1>
    <p class="sub">Stok awal dikelola lewat menu Stok (Barang Masuk) agar tercatat di histori.</p>
    <div class="card">
        @include('products._form', ['action' => route('products.store'), 'method' => 'POST'])
    </div>
@endsection
