@extends('layouts.app')

@section('title', 'Akses Ditolak')

@section('content')
    <div class="card error-page">
        <h2>403 - Akses Ditolak</h2>
        <p>{{ $exception->getMessage() ?: 'Anda tidak memiliki izin untuk membuka halaman ini.' }}</p>
        @auth
            <p>Role Anda: <strong>{{ auth()->user()->role }}</strong></p>
        @endauth
        <a class="btn" href="{{ route('dashboard') }}">Kembali ke Dashboard</a>
    </div>
@endsection
