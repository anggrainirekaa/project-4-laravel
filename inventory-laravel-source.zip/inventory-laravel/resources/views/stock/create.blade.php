@extends('layouts.app')

@section('title', $type === 'in' ? 'Barang Masuk' : 'Barang Keluar')

@section('content')
    <h1>{{ $type === 'in' ? 'Barang Masuk' : 'Barang Keluar' }}</h1>
    <p class="sub">
        {{ $type === 'in'
            ? 'Catat penerimaan barang; stok bertambah.'
            : 'Catat pengeluaran barang; stok berkurang dan tidak boleh melebihi stok tersedia.' }}
    </p>

    <div class="card">
        <form method="POST" action="{{ route('stock.store') }}" class="form">
            @csrf
            <input type="hidden" name="type" value="{{ $type }}">

            <label for="product_id">Produk</label>
            <select id="product_id" name="product_id">
                <option value="">-- pilih produk --</option>
                @foreach ($products as $product)
                    <option value="{{ $product->id }}" @selected(old('product_id', $selected) == $product->id)>
                        {{ $product->sku }} - {{ $product->name }} (stok: {{ $product->stock }})
                    </option>
                @endforeach
            </select>
            <x-field-error name="product_id" />

            <label for="quantity">Quantity</label>
            <input id="quantity" name="quantity" value="{{ old('quantity') }}">
            <x-field-error name="quantity" />

            <label for="note">Catatan</label>
            <input id="note" name="note" value="{{ old('note') }}" placeholder="Opsional">
            <x-field-error name="note" />

            <p style="margin-top:18px">
                <button type="submit" class="btn {{ $type === 'in' ? 'green' : 'danger' }}">
                    Simpan {{ $type === 'in' ? 'Barang Masuk' : 'Barang Keluar' }}
                </button>
                <a class="btn gray" href="{{ route('stock.index') }}">Batal</a>
            </p>
        </form>
    </div>
@endsection
