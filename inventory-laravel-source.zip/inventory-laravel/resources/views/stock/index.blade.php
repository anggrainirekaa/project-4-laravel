@extends('layouts.app')

@section('title', 'Histori Stok')

@section('content')
    <h1>Histori Transaksi Stok</h1>
    <p class="sub">Seluruh barang masuk dan keluar tersimpan permanen. Total: {{ $movements->total() }} transaksi.</p>

    <form method="GET" action="{{ route('stock.index') }}" class="toolbar">
        <input name="search" placeholder="Cari produk / SKU..." value="{{ request('search') }}">
        <select name="type">
            <option value="">Semua jenis</option>
            <option value="in" @selected(request('type') === 'in')>Masuk</option>
            <option value="out" @selected(request('type') === 'out')>Keluar</option>
        </select>
        <button class="btn">Terapkan</button>
        <a class="btn gray" href="{{ route('stock.index') }}">Reset</a>
        <span style="flex:1"></span>
        <a class="btn green" href="{{ route('stock.create', ['type' => 'in']) }}">+ Barang Masuk</a>
        <a class="btn danger" href="{{ route('stock.create', ['type' => 'out']) }}">- Barang Keluar</a>
    </form>

    <table>
        <tr><th>Waktu</th><th>SKU</th><th>Produk</th><th>Jenis</th><th class="right">Qty</th><th>Catatan</th><th>Oleh</th></tr>
        @forelse ($movements as $m)
            <tr>
                <td class="nowrap">{{ $m->created_at->format('d-m-Y H:i') }}</td>
                <td class="nowrap">{{ $m->product->sku }}</td>
                <td>{{ $m->product->name }}</td>
                <td><span class="badge {{ $m->type }}">{{ $m->type === 'in' ? 'Masuk' : 'Keluar' }}</span></td>
                <td class="right">{{ $m->quantity }}</td>
                <td class="muted">{{ $m->note ?: '-' }}</td>
                <td>{{ $m->user->name }}</td>
            </tr>
        @empty
            <tr><td colspan="7" class="muted">Belum ada transaksi.</td></tr>
        @endforelse
    </table>

    {{ $movements->links() }}
@endsection
