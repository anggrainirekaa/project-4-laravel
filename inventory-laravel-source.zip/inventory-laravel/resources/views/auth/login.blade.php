@extends('layouts.app')

@section('title', 'Login')

@section('content')
    <div class="login-wrap">
        <div class="card">
            <h1>&#128230; Inventory IMS</h1>
            <p class="sub">Silakan login untuk melanjutkan.</p>

            <form method="POST" action="{{ route('login.attempt') }}" class="form" autocomplete="off">
                @csrf
                <label for="username">Username</label>
                <input id="username" name="username" value="{{ old('username') }}">
                <x-field-error name="username" />

                <label for="password">Password</label>
                <input id="password" type="password" name="password">
                <x-field-error name="password" />

                <p><button type="submit" class="btn" style="width:100%">Login</button></p>
            </form>
            <p class="hint">Akun demo: <strong>admin</strong> / admin123 &nbsp;|&nbsp; <strong>staff</strong> / staff123</p>
        </div>
    </div>
@endsection
