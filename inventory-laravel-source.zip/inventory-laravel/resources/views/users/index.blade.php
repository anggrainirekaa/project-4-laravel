@extends('layouts.app')

@section('title', 'Administrasi User')

@section('content')
    <div class="page-head">
        <div>
            <h1>Administrasi User</h1>
            <p class="sub">Hanya admin yang dapat mengelola user. Password disimpan dengan hashing.</p>
        </div>
        <a class="btn green" href="{{ route('users.create') }}">+ Tambah User</a>
    </div>

    <table>
        <tr><th>Nama</th><th>Username</th><th>Email</th><th>Role</th><th>Aksi</th></tr>
        @foreach ($users as $user)
            <tr>
                <td>{{ $user->name }}</td>
                <td>{{ $user->username }}</td>
                <td>{{ $user->email }}</td>
                <td><span class="badge {{ $user->role }}">{{ $user->role }}</span></td>
                <td>
                    <form method="POST" action="{{ route('users.destroy', $user) }}" class="inline"
                          onsubmit="return confirm('Hapus user ini?')">
                        @csrf
                        @method('DELETE')
                        <button class="btn small danger">Hapus</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
@endsection
