@extends('layouts.app')

@section('title', 'Tambah User')

@section('content')
    <h1>Tambah User</h1>
    <div class="card">
        <form method="POST" action="{{ route('users.store') }}" class="form">
            @csrf
            <label for="name">Nama</label>
            <input id="name" name="name" value="{{ old('name') }}">
            <x-field-error name="name" />

            <label for="username">Username</label>
            <input id="username" name="username" value="{{ old('username') }}">
            <x-field-error name="username" />

            <label for="email">Email</label>
            <input id="email" name="email" value="{{ old('email') }}">
            <x-field-error name="email" />

            <label for="password">Password</label>
            <input id="password" type="password" name="password">
            <x-field-error name="password" />

            <label for="role">Role</label>
            <select id="role" name="role">
                <option value="staff" @selected(old('role') === 'staff')>staff</option>
                <option value="admin" @selected(old('role') === 'admin')>admin</option>
            </select>
            <x-field-error name="role" />

            <p style="margin-top:18px">
                <button type="submit" class="btn">Simpan</button>
                <a class="btn gray" href="{{ route('users.index') }}">Batal</a>
            </p>
        </form>
    </div>
@endsection
