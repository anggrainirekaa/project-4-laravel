@extends('layouts.app')

@section('title', 'Supplier')

@section('content')
    <div class="page-head">
        <div>
            <h1>Supplier</h1>
            <p class="sub">Satu produk dapat memiliki banyak supplier dan sebaliknya (many-to-many).</p>
        </div>
        <a class="btn green" href="{{ route('suppliers.create') }}">+ Tambah Supplier</a>
    </div>

    <table>
        <tr><th>Nama</th><th>Kontak</th><th class="right">Produk</th><th>Aksi</th></tr>
        @foreach ($suppliers as $supplier)
            <tr>
                <td>{{ $supplier->name }}<br><span class="muted">{{ $supplier->address }}</span></td>
                <td>{{ $supplier->phone ?: '-' }}<br><span class="muted">{{ $supplier->email }}</span></td>
                <td class="right">{{ $supplier->products_count }}</td>
                <td class="nowrap">
                    <a class="btn small" href="{{ route('suppliers.edit', $supplier) }}">Edit</a>
                    <form method="POST" action="{{ route('suppliers.destroy', $supplier) }}" class="inline"
                          onsubmit="return confirm('Hapus supplier ini?')">
                        @csrf
                        @method('DELETE')
                        <button class="btn small danger">Hapus</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
@endsection
