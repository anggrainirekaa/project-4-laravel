@extends('layouts.app')

@section('title', $supplier->exists ? 'Edit Supplier' : 'Tambah Supplier')

@section('content')
    <h1>{{ $supplier->exists ? 'Edit Supplier' : 'Tambah Supplier' }}</h1>
    <div class="card">
        <form method="POST" class="form"
              action="{{ $supplier->exists ? route('suppliers.update', $supplier) : route('suppliers.store') }}">
            @csrf
            @if ($supplier->exists)
                @method('PUT')
            @endif
            <label for="name">Nama</label>
            <input id="name" name="name" value="{{ old('name', $supplier->name) }}">
            <x-field-error name="name" />

            <label for="phone">Telepon</label>
            <input id="phone" name="phone" value="{{ old('phone', $supplier->phone) }}">
            <x-field-error name="phone" />

            <label for="email">Email</label>
            <input id="email" name="email" value="{{ old('email', $supplier->email) }}">
            <x-field-error name="email" />

            <label for="address">Alamat</label>
            <input id="address" name="address" value="{{ old('address', $supplier->address) }}">
            <x-field-error name="address" />

            <p style="margin-top:18px">
                <button type="submit" class="btn">Simpan</button>
                <a class="btn gray" href="{{ route('suppliers.index') }}">Batal</a>
            </p>
        </form>
    </div>
@endsection
