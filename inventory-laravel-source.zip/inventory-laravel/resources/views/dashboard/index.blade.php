@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
    <h1>Dashboard</h1>
    <p class="sub">Statistik dan laporan inventory. Selamat datang, {{ auth()->user()->name }}.</p>

    <div class="grid g4">
        <x-stat-card label="Total Produk" :value="$stats['products']" />
        <x-stat-card label="Total Unit Stok" :value="number_format($stats['units'], 0, ',', '.')" />
        <x-stat-card label="Nilai Persediaan" :value="'Rp '.number_format($stats['value'], 0, ',', '.')" tone="ok" />
        <x-stat-card label="Produk Stok Menipis" :value="$stats['low']" tone="warn" />
        <x-stat-card label="Kategori" :value="$stats['categories']" />
        <x-stat-card label="Supplier" :value="$stats['suppliers']" />
        <x-stat-card label="Total Barang Masuk" :value="number_format($stats['in'], 0, ',', '.')" tone="ok" />
        <x-stat-card label="Total Barang Keluar" :value="number_format($stats['out'], 0, ',', '.')" tone="warn" />
    </div>

    <div class="grid g2" style="margin-top:18px">
        <div class="card">
            <h2>Laporan Stok per Kategori</h2>
            <table>
                <tr><th>Kategori</th><th class="right">Produk</th><th class="right">Unit</th><th class="right">Nilai</th></tr>
                @foreach ($perCategory as $row)
                    <tr>
                        <td>{{ $row->name }}</td>
                        <td class="right">{{ $row->product_count }}</td>
                        <td class="right">{{ number_format($row->units, 0, ',', '.') }}</td>
                        <td class="right">Rp {{ number_format($row->value, 0, ',', '.') }}</td>
                    </tr>
                @endforeach
            </table>
        </div>

        <div class="card">
            <h2>Peringatan Stok Menipis</h2>
            <table>
                <tr><th>SKU</th><th>Produk</th><th class="right">Stok</th><th class="right">Min</th></tr>
                @forelse ($lowStock as $product)
                    <tr>
                        <td class="nowrap">{{ $product->sku }}</td>
                        <td>{{ $product->name }}</td>
                        <td class="right"><span class="badge low">{{ $product->stock }}</span></td>
                        <td class="right">{{ $product->minimum_stock }}</td>
                    </tr>
                @empty
                    <tr><td colspan="4" class="muted">Semua stok aman.</td></tr>
                @endforelse
            </table>
        </div>
    </div>

    <div class="card">
        <h2>Transaksi Terbaru</h2>
        <table>
            <tr><th>Waktu</th><th>Produk</th><th>Jenis</th><th class="right">Qty</th><th>Oleh</th></tr>
            @foreach ($recent as $m)
                <tr>
                    <td>{{ $m->created_at->format('d-m-Y H:i') }}</td>
                    <td>{{ $m->product->name }}</td>
                    <td><span class="badge {{ $m->type }}">{{ $m->type === 'in' ? 'Masuk' : 'Keluar' }}</span></td>
                    <td class="right">{{ $m->quantity }}</td>
                    <td>{{ $m->user->name }}</td>
                </tr>
            @endforeach
        </table>
    </div>
@endsection
