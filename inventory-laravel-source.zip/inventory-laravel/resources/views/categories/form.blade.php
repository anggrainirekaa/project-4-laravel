@extends('layouts.app')

@section('title', $category->exists ? 'Edit Kategori' : 'Tambah Kategori')

@section('content')
    <h1>{{ $category->exists ? 'Edit Kategori' : 'Tambah Kategori' }}</h1>
    <div class="card">
        <form method="POST" class="form"
              action="{{ $category->exists ? route('categories.update', $category) : route('categories.store') }}">
            @csrf
            @if ($category->exists)
                @method('PUT')
            @endif
            <label for="name">Nama Kategori</label>
            <input id="name" name="name" value="{{ old('name', $category->name) }}">
            <x-field-error name="name" />
            <p style="margin-top:18px">
                <button type="submit" class="btn">Simpan</button>
                <a class="btn gray" href="{{ route('categories.index') }}">Batal</a>
            </p>
        </form>
    </div>
@endsection
