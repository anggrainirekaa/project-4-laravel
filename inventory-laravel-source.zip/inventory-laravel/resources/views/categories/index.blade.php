@extends('layouts.app')

@section('title', 'Kategori')

@section('content')
    <div class="page-head">
        <div>
            <h1>Kategori</h1>
            <p class="sub">Master data kategori produk (Category hasMany Product).</p>
        </div>
        <a class="btn green" href="{{ route('categories.create') }}">+ Tambah Kategori</a>
    </div>

    <table>
        <tr><th>Nama</th><th class="right">Jumlah Produk</th><th>Aksi</th></tr>
        @foreach ($categories as $category)
            <tr>
                <td>{{ $category->name }}</td>
                <td class="right">{{ $category->products_count }}</td>
                <td class="nowrap">
                    <a class="btn small" href="{{ route('categories.edit', $category) }}">Edit</a>
                    <form method="POST" action="{{ route('categories.destroy', $category) }}" class="inline"
                          onsubmit="return confirm('Hapus kategori ini?')">
                        @csrf
                        @method('DELETE')
                        <button class="btn small danger">Hapus</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
@endsection
