@props(['label', 'value', 'tone' => ''])

<div class="stat {{ $tone }}">
    <div class="n">{{ $value }}</div>
    <div class="l">{{ $label }}</div>
</div>
