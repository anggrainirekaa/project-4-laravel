@props(['column', 'label', 'sort', 'dir'])

@php($next = ($sort === $column && $dir === 'asc') ? 'desc' : 'asc')

<a href="{{ route('products.index', array_merge(request()->query(), ['sort' => $column, 'dir' => $next, 'page' => 1])) }}">
    {{ $label }}@if ($sort === $column) {{ $dir === 'asc' ? '▲' : '▼' }}@endif
</a>
