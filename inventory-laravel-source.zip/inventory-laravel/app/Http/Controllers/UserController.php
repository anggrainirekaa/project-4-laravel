<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

/** Administrasi user: hanya admin (lihat middleware 'role:admin' di routes/web.php). */
class UserController extends Controller
{
    public function index(): View
    {
        return view('users.index', ['users' => User::orderBy('id')->get()]);
    }

    public function create(): View
    {
        return view('users.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'username' => ['required', 'string', 'max:50', 'unique:users,username'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:6'],
            'role' => ['required', Rule::in(['admin', 'staff'])],
        ]);

        User::create($validated);   // password otomatis di-hash oleh cast 'hashed'

        return redirect()->route('users.index')->with('success', 'User berhasil ditambahkan.');
    }

    public function destroy(Request $request, User $user): RedirectResponse
    {
        if ($user->is($request->user())) {
            return back()->with('error', 'Anda tidak dapat menghapus akun yang sedang dipakai.');
        }
        if ($user->stockMovements()->exists()) {
            return back()->with('error', 'User tidak dapat dihapus karena memiliki histori transaksi.');
        }

        $user->delete();

        return redirect()->route('users.index')->with('success', 'User dihapus.');
    }
}
