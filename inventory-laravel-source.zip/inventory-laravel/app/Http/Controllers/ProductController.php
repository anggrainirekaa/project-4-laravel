<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Supplier;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class ProductController extends Controller
{
    /** Kolom sorting yang diizinkan (whitelist). */
    private const SORTABLE = ['sku', 'name', 'category', 'price', 'stock'];

    public function index(Request $request): View
    {
        $sort = in_array($request->query('sort'), self::SORTABLE, true) ? $request->query('sort') : 'name';
        $dir = $request->query('dir') === 'desc' ? 'desc' : 'asc';

        $products = Product::with(['category', 'suppliers'])
            ->when($request->search, function ($query, $search) {
                $query->where(function ($q) use ($search) {
                    $q->where('name', 'like', "%{$search}%")
                        ->orWhere('sku', 'like', "%{$search}%");
                });
            })
            ->when($request->category_id, function ($query, $categoryId) {
                $query->where('category_id', $categoryId);
            })
            ->when(
                $sort === 'category',
                fn ($query) => $query->orderBy(
                    Category::select('name')->whereColumn('categories.id', 'products.category_id'),
                    $dir
                ),
                fn ($query) => $query->orderBy($sort, $dir)
            )
            ->paginate(8)
            ->withQueryString();   // search/filter/sort tetap ada saat pindah halaman

        $categories = Category::orderBy('name')->get();

        return view('products.index', compact('products', 'categories', 'sort', 'dir'));
    }

    public function create(): View
    {
        return view('products.create', [
            'product' => new Product(['minimum_stock' => 5]),
            'categories' => Category::orderBy('name')->get(),
            'suppliers' => Supplier::orderBy('name')->get(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate($this->rules());

        $product = Product::create(collect($validated)->except('suppliers')->all());
        $product->suppliers()->sync($validated['suppliers'] ?? []);

        return redirect()->route('products.index')
            ->with('success', 'Produk berhasil disimpan.');
    }

    public function show(Product $product): View
    {
        $product->load(['category', 'suppliers']);
        $movements = $product->stockMovements()->with('user')->latest('id')->limit(10)->get();

        return view('products.show', compact('product', 'movements'));
    }

    public function edit(Product $product): View
    {
        return view('products.edit', [
            'product' => $product->load('suppliers'),
            'categories' => Category::orderBy('name')->get(),
            'suppliers' => Supplier::orderBy('name')->get(),
        ]);
    }

    public function update(Request $request, Product $product): RedirectResponse
    {
        $validated = $request->validate($this->rules($product));

        $product->update(collect($validated)->except('suppliers')->all());
        $product->suppliers()->sync($validated['suppliers'] ?? []);

        return redirect()->route('products.index')
            ->with('success', 'Produk berhasil diperbarui.');
    }

    public function destroy(Product $product): RedirectResponse
    {
        // Business rule P4: produk yang memiliki histori tidak boleh dihapus sembarangan.
        if ($product->stockMovements()->exists()) {
            return redirect()->route('products.index')
                ->with('error', 'Produk tidak dapat dihapus karena sudah memiliki histori transaksi stok.');
        }

        $product->delete();

        return redirect()->route('products.index')->with('success', 'Produk berhasil dihapus.');
    }

    /** Stok tidak diubah dari form produk; gunakan menu Barang Masuk/Keluar agar tercatat di histori. */
    private function rules(?Product $product = null): array
    {
        return [
            'category_id' => ['required', 'exists:categories,id'],
            'sku' => ['required', 'string', 'max:40', Rule::unique('products', 'sku')->ignore($product)],
            'name' => ['required', 'string', 'max:150'],
            'price' => ['required', 'numeric', 'min:0'],
            'minimum_stock' => ['required', 'integer', 'min:0'],
            'suppliers' => ['nullable', 'array'],
            'suppliers.*' => ['exists:suppliers,id'],
        ];
    }
}
