<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\StockMovement;
use App\Models\Supplier;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function __invoke(): View
    {
        $stats = [
            'products' => Product::count(),
            'units' => (int) Product::sum('stock'),
            'value' => (float) Product::sum(DB::raw('price * stock')),
            'low' => Product::whereColumn('stock', '<=', 'minimum_stock')->count(),
            'categories' => Category::count(),
            'suppliers' => Supplier::count(),
            'in' => (int) StockMovement::where('type', StockMovement::TYPE_IN)->sum('quantity'),
            'out' => (int) StockMovement::where('type', StockMovement::TYPE_OUT)->sum('quantity'),
        ];

        // Laporan agregat per kategori (JOIN + GROUP BY).
        $perCategory = Category::query()
            ->leftJoin('products', 'products.category_id', '=', 'categories.id')
            ->select('categories.id', 'categories.name')
            ->selectRaw('COUNT(products.id) as product_count')
            ->selectRaw('COALESCE(SUM(products.stock), 0) as units')
            ->selectRaw('COALESCE(SUM(products.price * products.stock), 0) as value')
            ->groupBy('categories.id', 'categories.name')
            ->orderByDesc('units')
            ->get();

        $lowStock = Product::with('category')
            ->whereColumn('stock', '<=', 'minimum_stock')
            ->orderBy('stock')
            ->limit(6)
            ->get();

        $recent = StockMovement::with(['product', 'user'])->latest('id')->limit(6)->get();

        return view('dashboard.index', compact('stats', 'perCategory', 'lowStock', 'recent'));
    }
}
