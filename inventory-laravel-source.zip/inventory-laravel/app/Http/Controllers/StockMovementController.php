<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\StockMovement;
use App\Services\StockService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class StockMovementController extends Controller
{
    public function index(Request $request): View
    {
        $movements = StockMovement::with(['product', 'user'])
            ->when($request->type, fn ($q, $type) => $q->where('type', $type))
            ->when($request->search, function ($q, $search) {
                $q->whereHas('product', function ($p) use ($search) {
                    $p->where('name', 'like', "%{$search}%")->orWhere('sku', 'like', "%{$search}%");
                });
            })
            ->latest('id')
            ->paginate(10)
            ->withQueryString();

        return view('stock.index', compact('movements'));
    }

    public function create(Request $request): View
    {
        $type = $request->query('type') === StockMovement::TYPE_OUT ? StockMovement::TYPE_OUT : StockMovement::TYPE_IN;

        return view('stock.create', [
            'type' => $type,
            'products' => Product::orderBy('name')->get(['id', 'sku', 'name', 'stock']),
            'selected' => (int) $request->query('product_id'),
        ]);
    }

    public function store(Request $request, StockService $stock): RedirectResponse
    {
        $validated = $request->validate([
            'type' => ['required', Rule::in([StockMovement::TYPE_IN, StockMovement::TYPE_OUT])],
            'product_id' => ['required', 'exists:products,id'],
            'quantity' => ['required', 'integer', 'min:1'],
            'note' => ['nullable', 'string', 'max:255'],
        ]);

        // Transaction + aturan stok berada di StockService, bukan di controller.
        $stock->record(
            Product::findOrFail($validated['product_id']),
            $validated['type'],
            (int) $validated['quantity'],
            $validated['note'] ?? null,
            $request->user(),
        );

        return redirect()->route('stock.index')->with(
            'success',
            'Transaksi barang '.($validated['type'] === StockMovement::TYPE_IN ? 'masuk' : 'keluar').' berhasil dicatat.'
        );
    }
}
