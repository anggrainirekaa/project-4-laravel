<?php

namespace App\Services;

use App\Models\Product;
use App\Models\StockMovement;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Business logic transaksi stok (aturan dari P4 tetap dipertahankan):
 *  - barang keluar tidak boleh melebihi stok
 *  - stok tidak boleh negatif
 *  - perubahan stok dan histori disimpan dalam satu transaction (commit/rollback)
 */
class StockService
{
    public function record(Product $product, string $type, int $quantity, ?string $note, User $user): StockMovement
    {
        return DB::transaction(function () use ($product, $type, $quantity, $note, $user) {
            // Kunci baris produk agar dua transaksi bersamaan tidak membuat stok salah.
            $locked = Product::query()->whereKey($product->getKey())->lockForUpdate()->firstOrFail();

            if ($type === StockMovement::TYPE_OUT && $quantity > $locked->stock) {
                // Exception di dalam closure => seluruh transaction di-rollback.
                throw ValidationException::withMessages([
                    'quantity' => "Stok tidak mencukupi. Stok {$locked->name} saat ini {$locked->stock}, diminta {$quantity}.",
                ]);
            }

            $locked->stock = $type === StockMovement::TYPE_IN
                ? $locked->stock + $quantity
                : $locked->stock - $quantity;
            $locked->save();

            return StockMovement::create([
                'product_id' => $locked->id,
                'user_id' => $user->id,
                'type' => $type,
                'quantity' => $quantity,
                'note' => $note,
            ]);
        });
    }
}
